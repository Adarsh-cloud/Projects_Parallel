// These are the Test cases for COllection

package test;



import static org.junit.Assert.*;

import org.junit.Test;

import bean.BankBean;
import dao.BankDao;
import exceptions.LowBalanceException;
import service.BankService;

class InputTest {
	
	@Test
	void createAccountTest() {
		
		BankDao dao = new BankDao();
		
		dao.setData(1000, new BankBean("Adarsh", 123456, 1234, "Dehradun", "8937011919", 1000));
		
		BankBean bean = (BankBean) dao.getData().get(123456);
		
		assertEquals(123456, bean.getAccNo());
	}
	
	@Test
	void validateBalanceTest() {
		
		BankService service = new BankService();
		
		try {
			
			service.validateBalance(1000, -1);
		} 
		catch (LowBalanceException e) {
			
			e.printStackTrace();
		}	
	}
}