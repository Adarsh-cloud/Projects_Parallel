import { Component, OnInit } from '@angular/core';
import { WalletService } from '../../services/wallet.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SampleResponse } from 'src/app/models/SampleResponse.model';
@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {
  balanceForm: FormGroup;
  response: SampleResponse;
  constructor(private service: WalletService, private formBuilder: FormBuilder) {
  }
  ngOnInit() {
    this.balanceForm = this.formBuilder.group({
      accountNum: ['', [Validators.required, Validators.pattern("^[A-Z]{3}\\d{10}$")]],
      password: ['', Validators.required]
    });
  }
  get formControls() { return this.balanceForm.controls; }
  onSubmit() {
    if (this.balanceForm.invalid) {
      return;
    }
    let accountNum: string = this.formControls.accountNum.value;
    let password: string = this.formControls.password.value;
    this.balance(accountNum, password);
  }
  balance(accountNum: string, password: string) {
    this.service.balance(accountNum, password).then(response => { this.response = response;}
      , err => {
        if (err.success != undefined && err.success == false) {
          this.response = err;
        }
      });
  }

}
