import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { WalletService } from './services/wallet.service';
import { ShowBalanceComponent } from './components/show-balance/show-balance.component';
import { DepositAmountComponent } from './components/deposit-amount/deposit-amount.component';
import { WithdrawAmountComponent } from './components/withdraw-amount/withdraw-amount.component';
import { FundTransferComponent } from './components/fund-transfer/fund-transfer.component';
import { MenuComponent } from './components/menu/menu.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { CreateAccountComponent } from './components/create-account/create-account.component';
import { ShowTransactionsComponent } from './components/show-transactions/show-transactions.component';
import { HomeComponent } from './components/home/home.component';
import { AppComponent } from './app.component';
@NgModule({
  declarations: [
    AppComponent,
    ShowBalanceComponent,
    DepositAmountComponent,
    WithdrawAmountComponent,
    FundTransferComponent,
    MenuComponent,
    PageNotFoundComponent,
    CreateAccountComponent,
    WithdrawAmountComponent,
    ShowTransactionsComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, ReactiveFormsModule,
    HttpClientModule,
  ],
  providers: [HttpClient, WalletService],
  bootstrap: [AppComponent]
})
export class AppModule { }
