export class Account {
    accountNum: string;
    name: string;
    mobile: string;
    dob: string;
    balance:number;
    password: string;
    constructor(name?: string, mobile?: string, dob?: string, password?: string,balance?:number,accountNum?:string) {
        this.name = name;
        this.mobile = mobile;
        this.dob = dob;
        this.password = password;
        this.balance = balance;
        this.accountNum = accountNum;
    }
}