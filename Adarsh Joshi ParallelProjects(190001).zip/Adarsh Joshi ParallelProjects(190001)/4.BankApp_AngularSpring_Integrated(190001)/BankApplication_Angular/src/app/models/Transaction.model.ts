export class Transaction {
    id: string;
    time: string;
    amount: number;
    accountTo: string;
    accountFrom: string;
    remark: string;
    constructor(amount?: number, accountFrom?: string, accountTo?: string, remark?: string, id?: string, time?: string) {
        this.id = id;
        this.time = time;
        this.amount = amount;
        this.accountTo = accountTo;
        this.accountFrom = accountFrom;
        this.remark = remark;
    }
}