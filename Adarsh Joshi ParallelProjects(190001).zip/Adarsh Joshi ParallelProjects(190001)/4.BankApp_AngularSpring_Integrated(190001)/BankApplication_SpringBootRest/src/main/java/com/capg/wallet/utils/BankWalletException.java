// This is the exception class for no account found


package com.capg.wallet.utils;

public class BankWalletException extends Exception {

	/**
	 * Thrown when no account is found for a particular account number.
	 */
	private static final long serialVersionUID = 1L;

	public BankWalletException(String message) {
		super(message);
	}

}
